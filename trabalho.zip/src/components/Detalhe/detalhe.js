import { useState, useEffect } from "react";
import Title from "../Title/index";

const Detalhe = (props) => {

  const [DetalheFilme, setDetalheFilme] = useState({});
  const [CarregaDetalhe, setCarregaDetalhe] = useState(false);
  const [ErroDetalhe, setErroDetalhe] = useState(undefined);
  

  useEffect(() => {

    async function fetchDetalheFilme() {
      setCarregaDetalhe(true);

      try {
        const response = await fetch(
          `https://my-json-server.typicode.com/marycamila184/moviedetails/moviedetails/${props.movie}`
        );
        const json = await response.json();

        setDetalheFilme(json);
        setCarregaDetalhe(false);

      } catch(error) {
        console.error(error)
        setErroDetalhe({ error });
      }
    }

    fetchDetalheFilme();

  }, [props.movie]);

  return (
    <div>
      <Title title={"Detalhes do Filme"} />
      {CarregaDetalhe ? (
        <h1>Um momento, estamos carregando a página...</h1>
      ) : (
        <div className="bg-gray-100 min-h-scream">
          <div className="max-w-screen-lg mx-auto py-8">
            <div className="flex flex-col md:flex-row items-center md:items-start">
              <img
                className="rounded-lg w-64 md:mr-8 mb-4 md:mb-8"
                src={DetalheFilme.poster}
                alt={`Poster for ${DetalheFilme.titulo}`}
              />
              <div className="flex-1">
                <h1 className="text-4x1" font-bold mb-4>
                  {DetalheFilme.titulo} ({DetalheFilme.ano})
                </h1>
                <p className="text-gray-600 mb-4">
                  Assistido {DetalheFilme.assistido ? "Sim" : "Não"}
                </p>
                <p className="text-gray-600">{DetalheFilme.sinopse}</p>
              </div>  
            </div>  
          </div>  
        </div>  
      )}
    </div>
  );
};

export default Detalhe;
