import { Route, BrowserRouter as Router, Routes } from 'react-router-dom';

import Header from './components/Header/index';
import Footer from './components/Footer/index';
import RoutesConfig from './RoutesConfig';
import Detalhes from "./pages/Detalhes";

function App() {
  return (
    <Router>    
        <Header />
        <RoutesConfig />
        <Routes>
          <Route path="/Detalhes/:movie" Component={Detalhes}/>
        </Routes>
        <Footer />
    </Router>
  );
}


export default App;